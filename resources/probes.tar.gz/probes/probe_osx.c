#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main (int argc, char** argv){
	
	FILE *outfile;
	
	outfile = fopen("result","w");
	fputs("osx",outfile);
	
	fclose (outfile);
	
	return 0;
}
